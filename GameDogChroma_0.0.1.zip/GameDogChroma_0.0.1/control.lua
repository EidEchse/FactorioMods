require "util"
require "defines"

local lastUpdate;
local lastTick;


script.on_init(function()
	--?game.player.print("inited2")
end)

function writeStackJson(itemstack,i)
	stacksize = itemstack.prototype.stack_size
	StackJson = ""
	StackJson = StackJson..string.format("\r\n   \"slot-%s\": {",i)
	StackJson = StackJson..string.format("\r\n    \"id\": %s,",i)
	StackJson = StackJson..string.format("\r\n    \"name\": \"%s\",",itemstack.name)
	StackJson = StackJson..string.format("\r\n    \"type\": \"%s\",",itemstack.type)
	StackJson = StackJson..string.format("\r\n    \"count\": %s,",itemstack.count)
	StackJson = StackJson..string.format("\r\n    \"stacksize\": %s",stacksize)
	StackJson = StackJson.."\r\n   },"
	return StackJson
end

function writeInventoryJson(name,inventory)
	InventoryJson = ""
	InventoryJson = InventoryJson.."\r\n  \""..name.."\": {"
	stacks=""
	for i=1, #inventory do
		itemstack = inventory[i]
		if itemstack.valid_for_read then
			stacks = stacks..writeStackJson(itemstack,i)
		end
	end
	InventoryJson = InventoryJson..string.sub(stacks,0,-2).."\r\n  },"
	return InventoryJson
end

function UpdateFile(event)
	local newUpdate = "{"
	newUpdate = newUpdate..string.format("\r\n \"x\": %s,",game.player.character.position.x)
	newUpdate = newUpdate..string.format("\r\n \"y\": %s,",game.player.character.position.y)
	newUpdate = newUpdate..string.format("\r\n \"health\": %s,",game.player.character.health)
	newUpdate = newUpdate..string.format("\r\n \"crafting_queue_size\": %s,",game.player.character.crafting_queue_size)
	newUpdate = newUpdate..string.format("\r\n \"energy\": %s,",game.player.character.energy)
	newUpdate = newUpdate.."\r\n \"inventory\": {"
	
	inventoryJson = ""
	inventoryJson = inventoryJson..writeInventoryJson("quickbar", game.player.character.get_inventory(defines.inventory.player_quickbar))
	inventoryJson = inventoryJson..writeInventoryJson("tools", game.player.character.get_inventory(defines.inventory.player_tools))
	inventoryJson = inventoryJson..writeInventoryJson("armor", game.player.character.get_inventory(defines.inventory.player_armor))
	inventoryJson = inventoryJson..writeInventoryJson("ammo", game.player.character.get_inventory(defines.inventory.player_ammo))
	inventoryJson = inventoryJson..writeInventoryJson("guns", game.player.character.get_inventory(defines.inventory.player_guns))
			
	newUpdate = newUpdate..string.sub(inventoryJson,0,-2).."\r\n }"
	newUpdate = newUpdate.."\r\n}"
	
	if (lastUpdate == newUpdate) then
		do return end
	end
	lastUpdate = newUpdate
	game.write_file("gamedog_game_state.txt",newUpdate)
end


script.on_event(defines.events.on_tick, function(event)
	local newTick = math.floor(game.tick / 30)
	if (lastTick == newTick) then
		do return end
	end	
	lastTick = newTick
	UpdateFile(event)
end)


script.on_event(defines.events.on_entity_died, UpdateFile)