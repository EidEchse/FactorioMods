if not angelsmods then angelsmods = {} end
if not angelsmods.tech then angelsmods.tech = {} end
--if not angelsmods.components then angelsmods.components = {} end

require("prototypes.angels-tech-category")
require("prototypes.entities.equipment-categories")

-- require("prototypes.items.science-packs")
-- require("prototypes.items.circuits")
-- require("prototypes.items.intermediates")
require("prototypes.entities.equipment")

-- require("prototypes.buildings.angels-labs")
-- require("prototypes.buildings.angels-labs-enhance")
-- require("prototypes.buildings.angels-labs-exploration")
-- require("prototypes.buildings.angels-labs-energy")
-- require("prototypes.buildings.angels-labs-logistic")
-- require("prototypes.buildings.angels-labs-processing")
-- require("prototypes.buildings.angels-labs-war")

require("prototypes.recipes.equipment-recipes")
-- require("prototypes.recipes.science-packs-recipes")
-- require("prototypes.recipes.circuits-recipes")
-- require("prototypes.recipes.bob-tech-entity")

--require("prototypes.technology.angels-tech-technology")
require("prototypes.technology.angels-vequip-technology")