data:extend(
{
  {
    type = "equipment-category",
    name = "angels-light-attack"
  },
  {
    type = "equipment-category",
    name = "angels-heavy-attack"
  },
  {
    type = "equipment-category",
    name = "angels-repair"
  },
  {
    type = "equipment-category",
    name = "angels-light-defense"
  },
  {
    type = "equipment-category",
    name = "angels-heavy-defense"
  },
  {
    type = "equipment-category",
    name = "angels-energy"
  },
  {
    type = "equipment-category",
    name = "angels-construction"
  },
  {
    type = "equipment-category",
    name = "angels-movement"
  },
}
)