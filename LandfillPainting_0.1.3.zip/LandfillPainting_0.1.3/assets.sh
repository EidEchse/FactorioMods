#!/bin/bash
FACTORIO=~/factorio15

declare -A alphacmds
alphacmds["outer-corner"]="\
\( +clone -extent 32x32 -sparse-color bilinear '0,0 #000 7,0 #fff 23,31 #fff 0,31 #000' \
  \( +clone -sparse-color bilinear '0,8 #fff 31,24 #fff 31,31 #000 0,31 #000' \) -compose multiply -composite \
  \( +clone \( +clone -flip \) \( +clone -flop \) \( +clone -flip \) -append \) -delete 0 \
  \( +clone +clone +clone +clone +clone +clone +append \) -delete 0 \) \
\( -clone -1,-2 -compose multiply -composite \) -delete -2,-3"
alphacmds["side"]="\
\( +clone -extent 32x32 -sparse-color bilinear '0,24 #fff 31,24 #fff 31,31 #000 0,31 #000' \
  \( +clone \( +clone -transverse \) \( +clone -transpose \) \( +clone -transverse \) -append \) -delete 0 \
  \( +clone +clone +clone +clone +clone +clone +clone +clone +append \) -delete 0 \) \
\( -clone -1,-2 -compose multiply -composite \) -delete -2,-3"
  
mkdir -p graphics/icons
mkdir -p graphics/terrain/water

for s in dirt dirt-dark grass-dry grass-medium sand sand-dark red-desert red-desert-dark; do
  convert $FACTORIO/data/base/graphics/icons/landfill.png \
    \( $FACTORIO/data/base/graphics/terrain/$s/${s}1.png -extent 32x32+10+0 \) \
    \( -clone 0 -alpha extract -threshold 0 \) \
    \( -clone 1,2 -compose multiply -composite \) -delete 1,2 \
    \( -clone 0 -fill "#323232" -colorize 100 \) \
    \( -clone 0 -colorspace HSL -channel Hue -separate +colorspace +channel \) \
    \( -clone 2,3 -compose difference -composite -negate -level 90%,100% \) -delete 2,3 \
    \( -clone 0,1,2 -compose src-over -composite \) -delete 1,2 \
    +swap -compose copy-opacity -composite \
    graphics/icons/landfill-$s.png
done
for s in inner-corner outer-corner side; do
  cmd="convert $FACTORIO/data/base/graphics/terrain/water/water-$s.png \
    \( +clone -modulate 100,100,80 \) \( -clone 0 -fill \"#323232\" -colorize 100 \) \
    \( -clone 0 -colorspace HSL -channel Hue -separate +colorspace +channel \) \
    \( -clone 2,3 -compose difference -composite -negate -level 80%,100% \) -delete 2,3 \
    \( -clone 0,1,2 -compose src-over -composite \) -delete 0,1 \
    \( -clone 0 -negate \) -delete 0 ${alphacmds[$s]} -compose copy-opacity -composite graphics/terrain/water/water-$s.png"
  eval $cmd
  if [ "$DEBUG" != "" ]; then
    debugcmd="convert $FACTORIO/data/base/graphics/terrain/water/water-$s.png \
      -fill \"#fff\" -colorize 100 ${alphacmds[$s]} /tmp/debug-$s.png"
    eval $debugcmd
  fi
done
