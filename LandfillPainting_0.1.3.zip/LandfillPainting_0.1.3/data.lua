require "util"
require "config"

local function findname(t, name)
  for i,v in ipairs(t) do
    if v.name == name then
      return v
    end
  end
end

local terrains = {
  "dirt",
  "dirt-dark",
  "grass-dry",
  "grass-medium",
  "sand",
  "sand-dark",
  "red-desert",
  "red-desert-dark"
}

local baserecipe = data.raw.recipe['landfill']
local technology = data.raw.technology['landfill']

if landfillpainting.config.costStone and baserecipe.ingredients[1][1] == "stone" then
  baserecipe.ingredients[1][2] = landfillpainting.config.costStone
end

if data.raw.technology['water-washing-1'] and
   (data.raw.technology['water-washing-1'].enabled == nil or data.raw.technology['water-washing-1'].enabled) and
   data.raw.recipe['solid-mud-landfill'] then
  baserecipe = data.raw.recipe['solid-mud-landfill']
  technology = data.raw.technology['water-washing-1']
  if landfillpainting.config.costMud then
    findname(baserecipe.ingredients, 'solid-mud').amount = landfillpainting.config.costMud
  end
  data:extend({{
    type = "item-subgroup",
    name = "water-landfill",
    group = "water-treatment",
    order = "eb"
  }})
  baserecipe.subgroup = "water-landfill"
  baserecipe.order = nil
else
  data:extend({{
    type = "item-subgroup",
    name = "terrain-landfill",
    group = "logistics",
    order = "hb"
  }})
  baserecipe.subgroup = "terrain-landfill"
end

for _,v in ipairs(terrains) do
  local item = {
    type = "item",
    name = "landfill-" .. v,
    localised_name = {"item-name.landfill"},
    icon = "__LandfillPainting__/graphics/icons/landfill-" .. v .. ".png",
    flags = {"goes-to-main-inventory"},
    subgroup = "terrain",
    order = "c[landfill]-a[" .. v .. "]",
    stack_size = 100,
    place_as_tile =
    {
      result = v,
      condition_size = 1,
      condition = {}
    }
  }
  local recipe = util.table.deepcopy(baserecipe)
  recipe.name = "landfill-" .. v
  if recipe.results then
    recipe.results[1].name = "landfill-" .. v
  else
    recipe.result = "landfill-" .. v
  end

  data:extend({item})
  data:extend({recipe})
  if data.raw.tile['water'].allowed_neighbors then -- Other mods may remove this altogether
    table.insert(data.raw.tile['water'].allowed_neighbors, v)
  end
  table.insert(technology.effects, { type = "unlock-recipe", recipe = "landfill-" .. v })
end

data.raw.item['landfill'].order = "c[landfill]-a[grass]"
data.raw.item['landfill'].place_as_tile.condition = {}

local function settile(name, picture)
  if data.raw.tile['water'].variants[name].picture == "__base__/graphics/terrain/water/" .. picture then
    data.raw.tile['water'].variants[name].picture = "__LandfillPainting__/graphics/terrain/water/" .. picture
  end
end

settile("inner_corner", "water-inner-corner.png")
settile("outer_corner", "water-outer-corner.png")
settile("side", "water-side.png")
