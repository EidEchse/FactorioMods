-- Check that bobsmod plates is installed
bobIsAbout = false
if (settings.startup["sct-recipes"].value == "bobsmods" and bobmods and bobmods.plates) then
	bobIsAbout = true
end

if (bobIsAbout == true) then

end