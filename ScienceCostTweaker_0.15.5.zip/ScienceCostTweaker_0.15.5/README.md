# ScienceCostTweaker
Factorio Mod : Adjusts the cost of science packs and research.
