Wireless Signals
v-0.1.2
Author: ItsTheKais  ( kaiseryoshi@gmail.com )

A Factorio mod about using radios for fun and profit.


License information:

The models used for this mod's graphics were made by BS2001. They are available for "unrestricted use" and were obtained from: http://www.sharecg.com/v/81581/browse/5/3D-Model/48-models-OBJ

Any content not outlined above is available under the GNU Lesser General Public License v3.0:

https://www.gnu.org/licenses/gpl.txt
https://www.gnu.org/licenses/lgpl-3.0.txt