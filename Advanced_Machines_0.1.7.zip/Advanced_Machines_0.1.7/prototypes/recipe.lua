data:extend({
  {
    type = "recipe",
    name = "advanced-electric-furnace",
    ingredients = {
	{"electric-furnace", 1},
	{"stone-brick", 25},
	{"steel-plate", 25},
	{"advanced-circuit", 25},
	{"processing-unit", 5},
	},
    result = "advanced-electric-furnace",
    energy_required = 15,
    enabled = false
  },
  {
    type = "recipe",
    name = "advanced-chemical-plant",
    ingredients = {
	{"chemical-plant", 1},
    {"steel-plate", 15},
	{"pipe", 10},
    {"iron-gear-wheel", 25},
    {"electronic-circuit", 50},
	{"advanced-circuit", 25},
	{"processing-unit", 5},
    },
    result= "advanced-chemical-plant",
	energy_required = 30,
    enabled = false,
  },
  {
    type = "recipe",
    name = "advanced-beacon",
    enabled = false,
    energy_required = 60,
    ingredients =
    {
	  {"beacon", 1},
      {"electronic-circuit", 100},
      {"advanced-circuit", 50},
	  {"processing-unit", 25},
      {"steel-plate", 25},
      {"copper-cable", 50},
	  --{"effectivity-module", 1},
	  --{"speed-module", 1},
	  --{"productivity-module", 1},
	  -------------or---------------
	  --{"god-module", 1},
    },
    result = "advanced-beacon"
  },
  {
    type = "recipe",
    name = "speed-module-4",
    enabled = false,
    energy_required = 120,
    ingredients =
    {
	  {"advanced-circuit", 20},
	  {"processing-unit", 5},
	  {"speed-module-3", 4},
    },
    result = "speed-module-4"
  },
  {
    type = "recipe",
    name = "speed-module-5",
    enabled = false,
    energy_required = 240,
    ingredients =
    {
	  {"advanced-circuit", 25},
	  {"processing-unit", 5},
	  {"speed-module-4", 4},
    },
    result = "speed-module-5"
  },
  {
    type = "recipe",
    name = "effectivity-module-4",
    enabled = false,
    energy_required = 120,
    ingredients =
    {
	  {"advanced-circuit", 20},
	  {"processing-unit", 5},
	  {"effectivity-module-3", 4},
    },
    result = "effectivity-module-4"
  },
  {
    type = "recipe",
    name = "effectivity-module-5",
    enabled = false,
    energy_required = 240,
    ingredients =
    {
	  {"advanced-circuit", 25},
	  {"processing-unit", 5},
	  {"effectivity-module-4", 4},
    },
    result = "effectivity-module-5"
  },
  {
    type = "recipe",
    name = "productivity-module-4",
    enabled = false,
    energy_required = 120,
    ingredients =
    {
	  {"advanced-circuit", 20},
	  {"processing-unit", 5},
	  {"productivity-module-3", 4},
    },
    result = "productivity-module-4"
  },
  {
    type = "recipe",
    name = "productivity-module-5",
    enabled = false,
    energy_required = 240,
    ingredients =
    {
	  {"advanced-circuit", 25},
	  {"processing-unit", 5},
	  {"productivity-module-4", 4},
    },
    result = "productivity-module-5"
  },
  {
    type = "recipe",
    name = "extreme-heavy-oil-cracking",
    category = "chemistry",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {type="fluid", name="water", amount=250},
      {type="fluid", name="heavy-oil", amount=100}
    },
    results=
    {
      {type="fluid", name="petroleum-gas", amount=50}
    },
    main_product= "",
    icon = "__Advanced_Machines__/graphics/icons/fluids/extreme-heavy-oil-cracking.png",
    subgroup = "fluid-recipes",
    order = "b[fluid-chemistry]-b[heavy-oil-cracking]"
  },
  {
    type = "recipe",
    name = "extreme-oil-processing",
    category = "oil-processing",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {type="fluid", name="water", amount=100},
      {type="fluid", name="crude-oil", amount=250}
    },
    results=
    {
      {type="fluid", name="heavy-oil", amount=25},
      {type="fluid", name="light-oil", amount=100},
      {type="fluid", name="petroleum-gas", amount=150}
    },
    icon = "__Advanced_Machines__/graphics/icons/fluids/extreme-oil-processing.png",
    subgroup = "fluid-recipes",
    order = "a[oil-processing]-c[advanced-oil-processing]"
  },
})