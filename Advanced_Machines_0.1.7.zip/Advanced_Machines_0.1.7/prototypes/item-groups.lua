data:extend({
   {
    type = "item-group",
    name = "advanced-modules",
    order = "aa-a",
    inventory_order = "c-a",
    icon = "__Advanced_Machines__/graphics/icons/modulegroup.png",
  },
  {
    type = "item-subgroup",
    name = "beacons",
    group = "advanced-modules",
    order = "a-a",
  },
  --{
  --  type = "item-subgroup",
  --  name = "long-ranged-beacons",
  --  group = "advanced-modules",
  --  order = "b-a",
  --},
  {
    type = "item-subgroup",
    name = "effectivity",
    group = "advanced-modules",
    order = "b-a",
  },
  {
    type = "item-subgroup",
    name = "speed",
    group = "advanced-modules",
    order = "c-a",
  },
  {
    type = "item-subgroup",
    name = "productivity",
    group = "advanced-modules",
    order = "d-a",
  },
  {
    type = "item-subgroup",
    name = "effecient-speed",
    group = "advanced-modules",
    order = "f-a",
  },
  {
    type = "item-subgroup",
    name = "effecient-productivity",
    group = "advanced-modules",
    order = "g-a",
  },
  {
    type = "item-subgroup",
    name = "pure-productivity",
    group = "advanced-modules",
    order = "h-a",
  },
  {
    type = "item-subgroup",
    name = "god",
    group = "advanced-modules",
    order = "i-a",
  },
})