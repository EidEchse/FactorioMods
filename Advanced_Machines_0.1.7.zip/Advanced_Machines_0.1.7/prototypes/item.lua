data:extend({
  {
    type = "item",
    name = "advanced-electric-furnace",
    icon = "__Advanced_Machines__/graphics/icons/advanced-electric-furnace-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "smelting-machine",
    order = "e[electric-furnace]",
    place_result = "advanced-electric-furnace",
    stack_size = 10
  },
  {
    type = "item",
    name = "advanced-chemical-plant",
    icon = "__Advanced_Machines__/graphics/icons/advanced-chemical-plant-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "production-machine",
    order = "f[chemical-plant]",
    place_result = "advanced-chemical-plant",
    stack_size = 10
  } ,
  {
    type = "item",
    name = "advanced-beacon",
    icon = "__Advanced_Machines__/graphics/icons/advanced-beacon-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "module",
    order = "-a[beacon]",
    place_result = "advanced-beacon",
    stack_size = 10
  },
})