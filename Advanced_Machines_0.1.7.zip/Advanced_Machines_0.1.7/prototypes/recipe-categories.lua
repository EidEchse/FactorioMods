data:extend({
	{
	type = "recipe-category",
    name = "advanced-modules"
	},
}
)