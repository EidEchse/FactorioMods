--Dark Matter Replicators
repltech_item("tenemut", "exotic", {target = "ore", type = "var", multiplier = 3}, nil, {tier = 1})
repltech_recipe("dark-matter-scoop", "exotic", {tier = 2})
repltech_recipe("dark-matter-transducer", "exotic", {tier = 3})
repltech_recipe("matter-conduit", "exotic", {tier = 4})

repltech_recipe("replicator-1", "device3", {upgrade = true})
repltech_recipe("replicator-2", "device4", {upgrade = true})
repltech_recipe("replicator-3", "device4", {upgrade = true})
repltech_recipe("replicator-4", "device5", {upgrade = true})
repltech_recipe("replicator-5", "device5", {upgrade = true})