data:extend(
{
  {
    type = "item-group",
    hidden = true,
	name = "Recycling",
    icon = "__ZRecycling__/graphics/item-group/recycling.png",
    icon_size = 64,
    inventory_order = "e",
    order = "e"
  },
  {
    type = "item-subgroup",
    name = "recycling-machine",
    group = "production",
    order = "z",
  },
}
)