data:extend({
   {
      type = "double-setting",
      name = "ZRecycling-recoveryrate",
      setting_type = "startup",
      default_value = 100,
      minimum_value = 10,
      maximum_value = 100,
      order = "ba",
   },

})