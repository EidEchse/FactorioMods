data:extend({
    {
        type = "bool-setting",
        name = "research-queue_popup-on-queue-finish",
        localised_name = "Popup when queue finishes?",
        localised_description = "When enabled, the research queue will auto-open when it finishes",
        setting_type = "runtime-per-user",
        default_value = false
    }
})