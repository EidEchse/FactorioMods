data:extend({
{
    "type" = "startup",
	"name" = "SpaceX-game-mode",
    "data_type" = "string",
    "default_value" = "Classic","SpaceX Plus","SpaceX Extreme","Custom",
    "per_user" = false,
    "admin" = true,
    "name-key" = "SpaceX-game-mode",
    "description-key" = "SpaceX-game-mode"
},
})