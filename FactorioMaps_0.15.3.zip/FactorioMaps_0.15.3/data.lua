require "prototypes.sprites"
require "prototypes.fakePlayer"
