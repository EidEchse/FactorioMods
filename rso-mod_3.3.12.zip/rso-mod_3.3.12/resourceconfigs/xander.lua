function fillXanderConfig()
	config["stone"].allotment = 80

	config["apatite"] = {
		type="resource-ore",
		
		allotment=80,
		spawns_per_region={min=1, max=1},
		richness=15000,
		
		size={min=15, max=25},
		min_amount=500,
		
--		starting={richness=8000, size=25, probability=1},
	}

	config["bauxite"] = {
		type="resource-ore",
		
		allotment=80,
		spawns_per_region={min=1, max=1},
		richness=15000,
		
		size={min=15, max=25},
		min_amount=500,
		
		starting={richness=6000, size=20, probability=1},
	}

	config["garnierite"] = {
		type="resource-ore",
		
		allotment=80,
		spawns_per_region={min=1, max=1},
		richness=15000,
		
		size={min=15, max=25},
		min_amount=500,
		
--		starting={richness=8000, size=25, probability=1},
	}

	config["granitic"] = {
		type="resource-ore",
		
		allotment=80,
		spawns_per_region={min=1, max=1},
		richness=15000,
		
		size={min=15, max=25},
		min_amount=500,
		
		starting={richness=6000, size=15, probability=1},
	}

	config["heavy-sand"] = {
		type="resource-ore",
		
		allotment=80,
		spawns_per_region={min=1, max=1},
		richness=15000,
		
		size={min=15, max=25},
		min_amount=500,
		
--		starting={richness=8000, size=25, probability=1},
	}

	config["lead-ore"] = {
		type="resource-ore",
		
		allotment=80,
		spawns_per_region={min=1, max=1},
		richness=15000,
		
		size={min=15, max=25},
		min_amount=500,
		
		starting={richness=6000, size=15, probability=1},
	}

	config["mineral-water"] = {
		type="resource-liquid",
		minimum_amount=120000,
		allotment=70,
		spawns_per_region={min=1, max=2},
		richness={min=200000, max=400000}, -- richness per resource spawn
		size={min=2, max=5},
		
		starting={richness=400000, size=2, probability=1},
	}

	config["natural-gas"] = {
		type="resource-liquid",
		minimum_amount=120000,
		allotment=70,
		spawns_per_region={min=1, max=2},
		richness={min=200000, max=400000}, -- richness per resource spawn
		size={min=2, max=5},
	}

	config["sulfidic-ore"] = {
		type="resource-ore",
		
		allotment=80,
		spawns_per_region={min=1, max=1},
		richness=15000,
		
		size={min=15, max=25},
		min_amount=500,
		
--		starting={richness=8000, size=25, probability=1},
	}

end