if data.raw['string-setting'] and data.raw['string-setting']['sct-difficulty-cost'] and
   data.raw['int-setting'] and data.raw['int-setting']['SpaceX-research'] then
  -- Don't want increased research costs with SpaceMod, it's already expensive enough
  data.raw['string-setting']['sct-difficulty-cost'].default_value = "noadjustment"
end

if seablockconfig then
  for k,v in pairs(seablockconfig.data) do
    local t = v[1]
    if data.raw[t] then
      data.raw[t][k] = nil
    end
  end
end
