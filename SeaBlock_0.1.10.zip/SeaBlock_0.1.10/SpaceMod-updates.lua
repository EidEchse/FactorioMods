if not mods['SpaceMod'] then
  return
end

local recipes = {
  'low-density-structure',
  'rocket-control-unit',
  'assembly-robot',
  'satellite',
  'drydock-assembly',
  'fusion-reactor',
  'hull-component',
  'protection-field',
  'space-thruster',
  'fuel-cell',
  'habitation',
  'life-support',
  'command',
  'astrometrics',
  'ftl-drive'
}

local upgrades = {
  ['copper-plate'] = 'nitinol-alloy',
  ['steel-plate'] = 'titanium-plate',
  ['processing-unit'] = 'advanced-processing-unit',
  ['construction-robot'] = 'bob-construction-robot-4',
  ['speed-module-3'] = 'speed-module-8',
  ['effectivity-module-3'] = 'effectivity-module-8',
  ['productivity-module-3'] = 'productivity-module-8',
  ['solar-panel'] = 'solar-panel-large-3',
  ['accumulator'] = 'fast-accumulator-3',
  ['radar'] = 'radar-5',
  ['roboport'] = 'bob-roboport-4',
  ['fusion-reactor-equipment'] = 'fusion-reactor-equipment-4',
  ['energy-shield-mk2-equipment'] = 'energy-shield-mk6-equipment',
  ['pipe'] = 'titanium-pipe',
}

local function iterateingredients(recipe, func)
  if recipe.normal then
    func(recipe.normal.ingredients)
    func(recipe.expensive.ingredients)
  else
    func(recipe.ingredients)
  end
end

local function doupgrade(ingredients)
  for _, item in pairs(ingredients) do
    local nameidx = 1
    local amountidx = 2
    if item.name then nameidx = 'name' end
    if item.amount then amountidx = 'amount' end
    local upgrade = upgrades[item[nameidx]]
    if upgrade and (data.raw.item[upgrade] or data.raw.module[upgrade]) then
      item[nameidx] = upgrade
    end
  end
end

for _, recipe in pairs(recipes) do
  if data.raw.recipe[recipe] then
    iterateingredients(data.raw.recipe[recipe], doupgrade)
  end
end
