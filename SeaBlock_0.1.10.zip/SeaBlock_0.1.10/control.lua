require "config"

local startingsizes = { }
startingsizes['none'] = { -2, 2, -2, 2, 32 }
startingsizes['very-low'] = { -2, 2, -2, 2, 64 }
startingsizes['low'] = { -2, 2, -2, 2, 96 }
startingsizes['normal'] = { -2, 2, -2, 2, 128 }
startingsizes['high'] = { -3, 2, -2, 2, 176 }
startingsizes['very-high'] = { -3, 2, -3, 2, 256 }

seablock.giveresearch = function(force)
  local techs = {
    'landfill',
    'ore-crushing',
    'basic-chemistry',
    'basic-chemistry-2',
    'angels-coal-processing',
    'angels-sulfur-processing-1',
    'bio-processing-green',
    'bio-processing-brown',
    'water-treatment',
    'slag-processing-1'
  }
  local newforce = force.technologies[techs[1]].researched == false
  for _,v in ipairs(techs) do
    force.technologies[v].researched = true
  end
  if newforce then
    -- Move default research tech back to automation
    force.current_research = "automation"
    force.current_research = nil
  end
end

seablock.giveitems = function(entity)
  local landfill = 'landfill'
  if game.item_prototypes['landfill-dirt'] then
    landfill = 'landfill-dirt'
  end
  local stuff = {
    {landfill, 1000},
    {"stone-pipe", 100},
    {"stone-pipe-to-ground", 50},
    {"offshore-pump", 5},
    {"small-electric-pole", 50},
    {"solar-panel", 38},
    {"accumulator", 32},
    {"algae-farm", 8},
    {"angels-flare-stack", 10},
    {"angels-electrolyser", 4},
    {"hydro-plant", 4},
    {"clarifier", 4},
    {"chemical-plant", 4},
    {"liquifier", 6},
    {"filtration-unit", 1},
    {"filter-frame", 50},
    {"crystallizer", 2},
    {"ore-crusher", 2},
    {"small-lamp", 12}
  }
  for _,v in ipairs(stuff) do
    entity.insert{name = v[1], count = v[2]}
  end
  if game.difficulty_settings.recipe_difficulty == defines.difficulty_settings.recipe_difficulty.normal then
    entity.insert{name = "wood-pellets", count = 1000}
  end
end

script.on_event(defines.events.on_player_joined_game, function(e)
  seablock.giveresearch(game.players[e.player_index].force)
end)

script.on_event(defines.events.on_force_created, function(e)
  seablock.giveresearch(e.force)
end)

local function neighbourcount(surface, x, y, name)
  local count = 0
  for dx = -1, 1, 2 do
    if surface.get_tile(x + dx, y).name == name then
      count = count + 1
    end
  end
  for dy = -1, 1, 2 do
    if surface.get_tile(x, y + dy).name == name then
      count = count + 1
    end
  end
  return count
end

local function linefix(surface, x, y)
  local count = 0
  for dx = -1, 1, 2 do
    local n1 = surface.get_tile(x + dx, y).name
    local n2 = surface.get_tile(x + 2 * dx, y).name
    local n3 = surface.get_tile(x + 3 * dx, y).name
    if n1 == 'water' or n1 == 'dirt-dark' or
      n2 == 'water' or n2 == 'dirt-dark' or
      n3 == 'water' or n3 == 'dirt-dark' then
      count = count + 1
    end
  end
  if count > 1 then return true end
  count = 0
  for dy = -1, 1, 2 do
    local n1 = surface.get_tile(x, y + dy).name
    local n2 = surface.get_tile(x, y + 2 * dy).name
    local n3 = surface.get_tile(x, y + 3 * dy).name
    if n1 == 'water' or n1 == 'dirt-dark' or
      n2 == 'water' or n2 == 'dirt-dark' or
      n3 == 'water' or n3 == 'dirt-dark' then
      count = count + 1
    end
  end
  return count > 1
end

script.on_event(defines.events.on_chunk_generated, function(e)
  local surface = e.surface;
  local ltx = e.area.left_top.x
  local lty = e.area.left_top.y
  local rbx = e.area.right_bottom.x
  local rby = e.area.right_bottom.y
  local size = startingsizes[surface.map_gen_settings.starting_area]
  local coarsesize = size[5] + 32
  if ltx * ltx + lty * lty > coarsesize * coarsesize then return end

  local ground = 'grass'
  if game.item_prototypes['landfill-dirt'] then
    ground = 'dirt'
  end
  local ndx = size[1]
  local pdx = size[2]
  local ndy = size[3]
  local pdy = size[4]
  local startingsq = size[5] * size[5]
  local tiles = {}
  for y = lty - 1, rby do
    for x = ltx - 1, rbx do
      if x * x + y * y < startingsq then
        local existing = surface.get_tile(x,y).name
        if existing == 'dirt-dark' then
	  w = "water"
	elseif existing == 'water' then
	  w = "deepwater"
	  if neighbourcount(surface, x, y, 'dirt-dark') > 0 or
	    neighbourcount(surface, x, y, 'water') > 2 then
	    w = "water"
	  end
	elseif existing == 'grass' then
	  w = 'deepwater'
	  if linefix(surface, x, y) then
	    w = 'water'
	  end
	else
          w = "deepwater"
	end
        if x >= ndx and x <= pdx and y >= ndy and y <= pdy then
          if x >= ndx + 1 and x <= pdx - 1 and y >= ndy + 1 and y <= pdy - 1 then
            w = ground
	  else
	    w = "water"
	  end
        end
        table.insert(tiles, {name = w, position = {x, y}})
      end
    end
  end
  surface.set_tiles(tiles)
  if ltx == 0 and lty == 0 and seablock.config.EquipmentInChest then
    local chest = surface.create_entity({name = "iron-chest", position={0,0}, force = game.forces.neutral})
    seablock.giveitems(chest)
  end
end)

script.on_event(defines.events.on_player_created, function(e)
  local player = game.players[e.player_index]
  player.remove_item{name = 'burner-mining-drill', count = 1}
  player.remove_item{name = 'burner-ore-crusher', count = 1}
  player.insert{name = 'iron-axe', count = 1}
  if not seablock.config.EquipmentInChest then
    seablock.giveitems(player)
  end
end)

-- Heavy handed fix for mods that forget migration scripts
script.on_configuration_changed(function(cfg)
  for _, force in pairs(game.forces) do
    force.reset_technologies()
    force.reset_recipes()
    for _,tech in pairs(force.technologies) do
      if tech.researched then
        for _, effect in pairs(tech.effects) do
	  if effect.type == "unlock-recipe" then
	    force.recipes[effect.recipe].enabled = true
	  end
	end
      end
    end
  end
end)

