data:extend({
  {
    type = "recipe",
    name = "coal",
    category = "smelting",
    enabled = true,
    energy_required = 3.5,
    ingredients = {{"wood-bricks", 1}},
    result = "coal",
    result_count = 3
  },
  {
    type = "recipe",
    name = "algae-green-from-brown",
    category = "crafting-handonly",
    subgroup = "bio-processing-green",
    enabled = true,
    energy_required = 2,
    ingredients = {
      {type = "item", name = "algae-brown", amount = 1},
      {type = "item", name = "stone-crushed", amount = 1},
    },
    results = {
      {type = "item", name = "algae-green", amount = 1}
    }
  },
  {
    type = "recipe",
    name = "solder-alginic",
    category = "electronics",
    energy_required = 2,
    enabled = false,
    ingredients = {
      {"solder-alloy", 4},
      {"solid-alginic-acid", 1}
    },
    result = "solder",
    result_count = 8
  },
  {
    type = "recipe",
    name = "thermal-extractor-water",
    category = "thermal-extractor",
    subgroup = "water-treatment",
    order = "h[thermal-extractor-water]",
    energy_required = 5,
    enabled = false,
    ingredients = {
      {type = "fluid", name = "steam", amount = 100},
      {type = "item", name = "lithium-chloride", amount = 2}
    },
    results = {
      {type = "fluid", name = "thermal-water", amount = 100}
    }
  }
})
