for _, force in pairs(game.forces) do
  force.reset_recipes()
end
