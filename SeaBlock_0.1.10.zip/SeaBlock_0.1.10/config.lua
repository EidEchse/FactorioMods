if not seablock then seablock = {} end
if not seablock.config then seablock.config = {

EquipmentInChest = true

}
end
