require("prototypes.recipe")
require("prototypes.recipe-category")

table.insert(data.raw.player.player.crafting_categories, "crafting-handonly")

for _,v in pairs(data.raw.tile) do
  v.autoplace = nil
end

data.raw.tile['sand'].autoplace = {
  peaks = {{
    influence = 0.1
  }}
}
data.raw.tile['deepwater'].autoplace = {
  peaks = {
  {
    influence = -0.1,
    starting_area_weight_optimal = 1,
    starting_area_weight_range = 0,
    starting_area_weight_max_range = 0
  }}
}

local function worm_everywhere(distance)
  local ret = {
    sharpness = 1,
    control = "enemy-base",
    richness_multiplier = 1,
    richness_base = 0,
    force = "enemy",
    max_probability = 0.3,
    peaks = {
      {
        influence = 10,
	richness_influence = 100,
	tier_from_start_optimal = distance,
	tier_from_start_top_property_limit = distance,
	tier_from_start_max_range = distance * 2
      },
      {
        influence = -10,
        starting_area_weight_optimal = 1,
        starting_area_weight_range = 0.033,
        starting_area_weight_max_range = 0.033
      },
      {
        influence = -11
      }
    }
  }
  return ret
end

data.raw.turret['small-worm-turret'].autoplace = worm_everywhere(1)
data.raw.turret['medium-worm-turret'].autoplace = worm_everywhere(5)
data.raw.turret['big-worm-turret'].autoplace = worm_everywhere(11)

-- Build land for worms
local autoplace = {
  sharpness = 1,
  control = "enemy-base",
  richness_multiplier = 1,
  richness_base = 0,
  force = "enemy",
  max_probability = 0.6,
  peaks = {
  {
    influence = -1,
    starting_area_weight_optimal = 1,
    starting_area_weight_range = 0.001,
    starting_area_weight_max_range = 0.001,
  },
  {
    influence = 0.77,
    noise_layer = 'enemy-base',
    noise_octaves_difference = -3,
    noise_persistence = 0.2,
  },
  {
    influence = 0.33,
    noise_layer = 'enemy-base',
    noise_octaves_difference = -3,
    noise_persistence = 0.2,
  },
  {
    influence = -1.8
  }}
}
local ground = 'grass'
if data.raw.item['landfill-dirt'] then
  ground = 'dirt'
end
data.raw.tile[ground].autoplace = autoplace

-- Shallow water around worm islands
autoplace = table.deepcopy(autoplace)
autoplace.peaks[4].influence = -1
data.raw.tile['water'].autoplace = autoplace

-- Use dirt-dark as marker for where shallow water should be in starting zone
autoplace = table.deepcopy(autoplace)
autoplace.peaks[1] = {
  influence = 1,
  starting_area_weight_optimal = 1,
  starting_area_weight_range = 0.01,
  starting_area_weight_max_range = 0.01
}
autoplace.peaks[4].influence = -0.3
data.raw.tile['dirt-dark'].autoplace = autoplace

--[[
autoplace = data.raw.tile['water'].autoplace
for _,peak in pairs(autoplace.peaks) do
  print("")
  for k,v in pairs(peak) do
    print(k .. " = " .. v)
  end
end
]]--
--[[
local function search(t, path, s)
  for k,v in pairs(t) do
    p = path .. "." .. k
    if string.find(k, s) then
      print(p)
    end
    if type(v) == 'string' and string.find(v, s) then
      print(p .. '=' .. v)
    end
    if type(v) == 'table' then
      search(v, p, s)
    end
  end
end
search(data.raw, "data.raw", "autoplace")
]]--
