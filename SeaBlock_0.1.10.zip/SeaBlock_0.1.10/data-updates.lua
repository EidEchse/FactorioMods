local lib = require "lib"
local function makestripes(filename, count)
  local r = {}
  for i = 1,count do
    table.insert(r, { filename = filename, width_in_frames = 1, height_in_frames = 1 })
  end
  return r
end

local function makeextractorlayers(bottom, top)
  layers = {}
  if top then
    table.insert(layers,
      {
        stripes = makestripes("__angelsrefining__/graphics/entity/thermal-extractor/thermal-extractor-base.png", 16),
        priority = "high",
        width = 288,
        height = 288,
        shift = {0, 0},
        frame_count = 16,
        x = 288 * 2,
	animation_speed = 0.5
      })
  end
  table.insert(layers,
    {
      priority = "high",
      width = 288,
      height = 288,
      line_length = 4,
      shift = {0, 0},
      filename = "__angelsrefining__/graphics/entity/thermal-extractor/thermal-extractor-animation.png",
      frame_count = 16,
      animation_speed = 0.5
    })
  if bottom then
    table.insert(layers,
      {
        stripes = makestripes("__angelsrefining__/graphics/entity/thermal-extractor/thermal-extractor-base.png", 16),
        priority = "high",
        width = 288,
        height = 288,
        shift = {0, 0},
        frame_count = 16,
        x = 0,
	animation_speed = 0.5
      })
  end
  return { layers = layers }
end

-- Make these craftable by hand
data.raw.recipe['solid-alginic-acid'].category = "crafting"
data.raw.recipe['circuit-wood-fiber-board'].category = "crafting"

-- Fix handcrafting trying to use wrong crafting path
data.raw.recipe['wooden-board'].category = "electronics-machine"

-- Change resin item icon to match resin recipe icon
data.raw.item['resin'].icon = "__angelspetrochem__/graphics/icons/solid-resin-1.png"

-- Add resin prerequisite for advanced electronics
table.insert(data.raw.technology['advanced-electronics'].prerequisites, "resin-1")

-- Plastics prerequisite
table.insert(data.raw.technology['plastics'].prerequisites, 'plastic-1')

-- Add unlock for new solder recipe
table.insert(data.raw.technology['electronics'].effects, { type = "unlock-recipe", recipe = "solder-alginic" })

-- No wood for electric poles, use wood bricks instead
data.raw.recipe['small-electric-pole'].ingredients = {{ "wood-bricks", 1 }, { "copper-cable", 2}}

-- Will need a lot of landfill
data.raw.recipe['landfill'].ingredients = {{ "stone-crushed", 10 }}
for k,v in pairs(data.raw.item) do
  if string.sub(k, 1, 8) == "landfill" then
    v.stack_size = 1000
  end
end

-- Prefer dirt for basic landfill crafting
if data.raw.item['landfill-dirt'] then
  data.raw.recipe['landfill'].result = "landfill-dirt"
end

-- Speed up algae farm
data.raw['assembling-machine']['algae-farm'].crafting_speed = 1
data.raw['assembling-machine']['algae-farm'].energy_usage = "120kW"

-- Increase output from nodule->slag slurry conversion, so washing plants are
-- competitive with electrolyzers for slag slurry production.
-- The dirt water electrolyzation recipe produces 10 slag-slurry worth of slag every 2 seconds. 5 per second.
-- When using washing plants, the default recipes take 50 seconds to produce
-- enough nodules to make 50 slag-slurry. 1 per second.
-- So divide input amount of nodules by 5 to make ratio equal.
-- Previous versions of sea block gave washing a 20% advantage. This was chosen before washing
-- plants MK2 were available, and was a bit high. MK2 washing plants should not be better than MK4 electrolyzers.
lib.findname(data.raw.recipe['nodule-dissolution'].ingredients, 'solid-nodule').amount = 2 -- was 10

-- Enable nodule-dissolution recipe
if data.raw.recipe['nodule-dissolution'] and
  lib.findtechunlock('nodule-dissolution') == nil and
  data.raw.technology['nodule-processing'] then
  table.insert(data.raw.technology['nodule-processing'].effects, {type = "unlock-recipe", recipe = "nodule-dissolution"})
end

-- Reduce sulfuric acid requirements for slag slurry production
lib.findname(data.raw.recipe['slag-processing-dissolution'].ingredients, 'sulfuric-acid').amount = 12
lib.findname(data.raw.recipe['stone-crushed-dissolution'].ingredients, 'sulfuric-acid').amount = 12
lib.findname(data.raw.recipe['nodule-dissolution'].ingredients, 'sulfuric-acid').amount = 12

-- Angels sludge crystalization usually gives normal smeltable ores. This would be far too easy,
-- so change recipes to give the weird ores that need extra processing steps.
for i = 1,6 do
  local recipe = data.raw.recipe["slag-processing-" .. i]
  recipe.icon = "__angelsrefining__/graphics/icons/angels-ore" .. i .. ".png"
  recipe.localised_name = {"recipe-name.slag-processing-1", {"item-name.angels-ore" .. i}, "", ""}
  recipe.order = "a-a [angels-ore-" .. i .. "]"

  recipe.ingredients = nil
  recipe.results = nil
  recipe.energy_required = nil

  recipe.normal = {
    energy_required = 4,
    ingredients = {{ type="fluid", name = 'mineral-sludge', amount = 25 }},
    results = {{type = "item", name = "angels-ore" .. i, amount = 1 }},
    enabled = false
  }

  recipe.expensive = {
    energy_required = 8,
    ingredients = {{ type="fluid", name = 'mineral-sludge', amount = 50 }},
    results = {{type = "item", name = "angels-ore" .. i, amount = 1 }},
    enabled = false
  }
end
-- Want angels ores 1,3,5,6 (Saphirite, Stiratite, Rubyte, Bobmonium) available from the start,
-- so shuffle crystallization recipe unlocks around
local slag1start = lib.findeffectidx(data.raw.technology['slag-processing-1'].effects, 'slag-processing-1')
local slag2start = lib.findeffectidx(data.raw.technology['slag-processing-2'].effects, 'slag-processing-4')
table.insert(data.raw.technology['slag-processing-2'].effects,
  slag2start + 1,
  lib.takeeffect(data.raw.technology['slag-processing-1'].effects, 'slag-processing-2')) -- move ore2 to slag-processing-2

table.insert(data.raw.technology['slag-processing-1'].effects,
  slag1start + 2,
  lib.takeeffect(data.raw.technology['slag-processing-2'].effects, 'slag-processing-5')) -- move ore5 to slag-processing-1

table.insert(data.raw.technology['slag-processing-1'].effects,
  slag1start + 3,
  lib.takeeffect(data.raw.technology['slag-processing-2'].effects, 'slag-processing-6')) -- move ore6 to slag-processing-1

-- Move crystallization ore recipes up above crushed ores
data.raw['item-subgroup']['slag-processing'].order = "ab"

-- Remove blue science requirement for slag-processing-2 technology
-- Needed for gold ore
-- Update: Not needed for gold now we unlock Rubyte ore with the above technology shuffle.
-- Leave change in because slag-processing-2 unlocks ceramic filters, which are quite helpful.
-- Also, having a source of silver (from crotinnum) early allows making resin/rubber
lib.removeingredient(data.raw.technology['slag-processing-2'].unit.ingredients, 'science-pack-3')

-- Need coal cracking to be accessable from green science level
data.raw.technology['angels-coal-cracking'].prerequisites = {'angels-advanced-chemistry-1'}
lib.removeingredient(data.raw.technology['angels-coal-cracking'].unit.ingredients, 'science-pack-3')

-- Need sulfur available from the start, so move coke with sulfuric waste water recipe to coal-processing-1
table.insert(data.raw.technology['angels-coal-processing'].effects,
  lib.takeeffect(data.raw.technology['angels-coal-processing-2'].effects, 'solid-coke-sulfur'))

-- Add alien bioprocessing prerequisite for technologies that need alien artifacts
local artifacttech = 'bio-processing-alien'
if data.raw.technology['big-alien-artifacts'] and
  (data.raw.technology['big-alien-artifacts'].enabled == nil or
   data.raw.technology['big-alien-artifacts'].enabled) then
   artifacttech = 'big-alien-artifacts'
end
if data.raw.technology['alien-research'] then
  table.insert(data.raw.technology['alien-research'].prerequisites, artifacttech)
end

-- Use Alginic acid instead of resin for ScienceCostTweaker red and green science packs
lib.substingredient("sct-t1-magnet-coils", "resin", "solid-alginic-acid")
lib.substingredient("sct-t2-micro-wafer", "resin", "solid-alginic-acid")
lib.substingredient("sct-t2-wafer-stamp", "resin", "solid-alginic-acid")

-- No way to make light fuel/fuel oil, so use methanol instead
lib.substingredient("sct-t3-flash-fuel", "light-oil", "gas-methanol")

-- Move misc sciencey things over to science tab
if data.raw['item-group']['sct-science'] then
  data:extend({
    {
      type = "item-subgroup",
      name = "sb-morelabs",
      group = "sct-science",
      order = "ab-a"
    }
  })
  if data.raw.item['lab-alien'] then
    data.raw.item['lab-alien'].subgroup = "sb-morelabs"
  end
  if data.raw.item['lab-module'] then
    data.raw.item['lab-module'].subgroup = "sb-morelabs"
  end
  if data.raw.item['lab-2'] then
    data.raw.item['lab-2'].subgroup = "sct-labs"
    data.raw.item['lab-2'].order = "e[lab-2]"
    -- Update lab MK2 ingredients and energy usage
    data.raw.lab['lab-2'].energy_usage = "3MW"
    lib.substingredient('lab-2', 'lab', 'sct-lab-4')
    lib.substingredient('lab-2', 'advanced-circuit', 'advanced-processing-unit')
  end
  data.raw['item-subgroup']['science-pack'].group = "sct-science"
  data.raw['item-subgroup']['science-pack'].order = "i"

  -- Put centrifuge next to nuclear components
  data.raw.item['centrifuge'].subgroup = "energy"
  data.raw.item['centrifuge'].order = "f[nuclear-energy]-a[centrifuge]"
end

-- No coal liquefaction, should use angels cracking recipes instead
data.raw.technology['coal-liquefaction'].enabled = false

-- No fuel value on these because they are also smelting inputs
-- https://forums.factorio.com/viewtopic.php?f=23&t=46634
data.raw.item['wood-bricks'].fuel_value = nil
data.raw.item['wood-bricks'].fuel_category = nil
data.raw.item['coal-crushed'].fuel_value = nil
data.raw.item['coal-crushed'].fuel_category = nil

-- Easier circuits for electrolyzer
lib.substingredient("angels-electrolyser", "electronic-circuit", "basic-circuit-board")

-- No natural gas, use methane for manganese pellet smelting
lib.substingredient("pellet-manganese-smelting", "gas-natural-1", "gas-methane")

-- Repurpose thermal extractor
local extractor = data.raw['mining-drill']['thermal-extractor']
data.raw['mining-drill']['thermal-extractor'] = nil
data.raw['assembling-machine']['thermal-extractor'] = extractor
extractor.type = 'assembling-machine'
extractor.crafting_speed = 1
extractor.ingredient_count = 2
extractor.fluid_boxes = {
  {
    production_type = 'input',
    base_area = 10,
    base_level = -1,
    pipe_covers = pipecoverspictures(),
    pipe_connections = {{ type = 'input', position = { 5, 3 } }}
  },
  {
    production_type = 'output',
    base_area = 10,
    base_level = 1,
    pipe_covers = pipecoverspictures(),
    pipe_connections = {{ type = 'output', position = { -5, -3 } }}
  }
}
extractor.animation = {
  north = makeextractorlayers(false, false),
  east = makeextractorlayers(true, true),
  south = makeextractorlayers(false, false),
  west = makeextractorlayers(true, true),
}
extractor.crafting_categories = { "thermal-extractor" }
extractor.fixed_recipe = "thermal-extractor-water"
table.insert(data.raw.technology['thermal-water-extraction'].effects,
  { type = "unlock-recipe", recipe = "thermal-extractor-water" })

-- Circuit network wires should not require rubber
data.raw.recipe['green-wire'].ingredients = {{ "electronic-circuit", 1 }, { "copper-cable", 1 }}
data.raw.recipe['red-wire'].ingredients = {{ "electronic-circuit", 1 }, { "copper-cable", 1 }}
if data.raw.recipe['sct-prod-bioprocessor'] then
  lib.substingredient("sct-prod-bioprocessor", "red-wire", "insulated-cable")
end

-- No resource placement
for k,v in pairs(data.raw.resource) do
  v.autoplace = nil
end
-- No spawners
for k,v in pairs(data.raw["unit-spawner"]) do
  v.autoplace = nil
  v.control = nil
end
-- No trees
for k,v in pairs(data.raw.tree) do
  v.autoplace = nil
end
-- No rocks
for k,v in pairs(data.raw["simple-entity"]) do
  v.autoplace = nil
end

local controls = data.raw['autoplace-control']
for k,v in pairs(controls) do
  if k ~= "enemy-base" then
    controls[k] = nil
  end
end

-- SpaceMod temp updates
require "SpaceMod-updates"
