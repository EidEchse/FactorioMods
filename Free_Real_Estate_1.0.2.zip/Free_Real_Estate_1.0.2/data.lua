require('config')

require('prototypes.entities')
require('prototypes.items')
require('prototypes.recipes')
require('prototypes.technologies')
require('prototypes.tiles')
require('prototypes.styles')

require('prototypes.relays.items')
require('prototypes.relays.pipes')
require('prototypes.relays.circuits')