meme_magic = {
	"It's free! Real estate!",
	"It's real estate. Free!",
	"That's a free house for you Jim!",
	"This is free real estate.",
	"Two bedrooms. No rugs.",
	"It's a two bedroom house; it's free, it's a got a pool in the back.",
	"It's free real estate ;)",
}