data:extend(
{
	{
		type = "item-subgroup",
		name = "electric-transport",
		group = "logistics",
		order = "ee",
	},
})