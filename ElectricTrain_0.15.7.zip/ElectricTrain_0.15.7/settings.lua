data:extend({
	{
		type = "bool-setting",
		name = "hybrid-train",
		setting_type = "startup",
		default_value = "true",
	},
})