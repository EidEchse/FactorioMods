data.raw.resource["stone"].infinite = true
data.raw.resource["stone"].infinite_depletion_amount = 0
data.raw.resource["stone"].normal  = 10
data.raw.resource["stone"].minimum  = 10

data.raw.resource["coal"].infinite = true
data.raw.resource["coal"].infinite_depletion_amount = 0
data.raw.resource["coal"].normal  = 10
data.raw.resource["coal"].minimum  = 10

data.raw.resource["iron-ore"].infinite = true
data.raw.resource["iron-ore"].infinite_depletion_amount = 0
data.raw.resource["iron-ore"].normal  = 10
data.raw.resource["iron-ore"].minimum  = 10

data.raw.resource["copper-ore"].infinite = true
data.raw.resource["copper-ore"].infinite_depletion_amount = 0
data.raw.resource["copper-ore"].normal  = 10
data.raw.resource["copper-ore"].minimum  = 10

data.raw.resource["uranium-ore"].infinite = true
data.raw.resource["uranium-ore"].infinite_depletion_amount = 0
data.raw.resource["uranium-ore"].normal  = 10
data.raw.resource["uranium-ore"].minimum  = 10

data.raw.resource["crude-oil"].infinite = true
data.raw.resource["crude-oil"].infinite_depletion_amount = 0
data.raw.resource["crude-oil"].minimum  = data.raw.resource["crude-oil"].normal