data:extend({
  {
    type = "custom-input",
    name = "inserter-drop-distance-toggle",
    key_sequence = "CONTROL + F",
    consuming = "script-only"
  },
  {
    type = "custom-input",
    name = "inserter-drop-lateral-adjust",
    key_sequence = "CONTROL + SHIFT + F",
    consuming = "script-only"
  },
  {
    type = "custom-input",
    name = "rotate-inserter-pickup",
    key_sequence = "CONTROL + R",
    consuming = "script-only"
  },
  {
    type = "custom-input",
    name = "reverse-rotate-inserter-pickup",
    key_sequence = "CONTROL + SHIFT + R",
    consuming = "script-only"
  }
})