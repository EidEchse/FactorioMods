--algae farm order

local function item_order(item, order)
	if data.raw.item[item] then
		data.raw["item"][item].order = order
	end
end

item_order("algae-farm", "a[algae-farm-1]")
item_order("algae-farm-2", "a[algae-farm-2]")

local function hide_disable_recipe(recipe)
	if not data.raw.recipe[recipe] then return end
	if data.raw.recipe[recipe].normal then
		data.raw.recipe[recipe].normal.hidden = true
		data.raw.recipe[recipe].normal.enabled = false
		data.raw.recipe[recipe].expensive.hidden = true
		data.raw.recipe[recipe].expensive.enabled = false
	else
		data.raw.recipe[recipe].hidden = true
		data.raw.recipe[recipe].enabled = false
	end
end

local function remove_tech_recipe_unlock(tech, effect)
	if not data.raw.technology[tech] or not data.raw.technology[tech].effects then return end
	for k, v in pairs(data.raw.technology[tech].effects) do
		if v.recipe == effect then
			data.raw.technology[tech].effects[k] = nil
		end
	end
end

local function add_item_flag(item, flag)
	if not data.raw.item[item] then return end
	if not data.raw.item[item].flags then
		data.raw.item[item].flags = {flag}
	else
		table.insert(data.raw.item[item].flags, flag)
	end
end

local function disable_tech(tech)
	if data.raw.technology[tech] then
		data.raw.technology[tech].enabled = false
	end
end

--remove oil refineries from tech and hide recipe since they don't do anything, same for water pump, there the tech is completely removed

if mods["angelsrefining"] and mods["angelspetrochem"] and mods["bobassembly"] and mods["SeaBlock"] and mods["A Sea Block Config"] then
	hide_disable_recipe("oil-refinery")
	hide_disable_recipe("oil-refinery-2")
	hide_disable_recipe("oil-refinery-3")
	hide_disable_recipe("oil-refinery-4")
	
	add_item_flag("oil-refinery", "hidden")
	add_item_flag("oil-refinery-2", "hidden")
	add_item_flag("oil-refinery-3", "hidden")
	add_item_flag("oil-refinery-4", "hidden")
	
	remove_tech_recipe_unlock("angels-oil-processing", "oil-refinery")
	remove_tech_recipe_unlock("angels-advanced-chemistry-2", "oil-refinery-2")
	remove_tech_recipe_unlock("angels-advanced-chemistry-3", "oil-refinery-3")
	remove_tech_recipe_unlock("angels-advanced-chemistry-4", "oil-refinery-4")
end

if mods["angelsrefining"] and mods["bobplates"] then
	hide_disable_recipe("water-pump")
	hide_disable_recipe("water-pump-2")
	hide_disable_recipe("water-pump-3")
	hide_disable_recipe("water-pump-4")
	
	add_item_flag("water-pump", "hidden")
	add_item_flag("water-pump-2", "hidden")
	add_item_flag("water-pump-3", "hidden")
	add_item_flag("water-pump-4", "hidden")
	
	--remove tech effect for completeness, but I'm removing the tech completely
	remove_tech_recipe_unlock("water-bore-1", "water-pump")
	remove_tech_recipe_unlock("water-bore-2", "water-pump-2")
	remove_tech_recipe_unlock("water-bore-3", "water-pump-3")
	remove_tech_recipe_unlock("water-bore-4", "water-pump-4")
	
	disable_tech("water-bore-1")
	disable_tech("water-bore-2")
	disable_tech("water-bore-3")
	disable_tech("water-bore-4")
end

--clay bricks tile name missing localisation

if data.raw.tile["clay-bricks"] then
	data.raw.tile["clay-bricks"].localised_name = {"item-name.clay-brick"}
end

--fix weird bobs electrolyser unlocking (no longer gets unlocked before its TWO recipes)
if mods["angelsrefining"] and mods["angelspetrochem"] and mods["bobassembly"] and mods["bobplates"] then
	if data.raw.technology["electrolyser-2"] and data.raw.technology["electrolyser-2"].prerequisites and data.raw.technology["lithium-processing"] then
		table.insert(data.raw.technology["electrolyser-2"].prerequisites, "lithium-processing")
	end
	
	if data.raw.technology["lithium-processing"] and data.raw.technology["lithium-processing"].effects and data.raw.recipe["electrolyser"] then
		table.insert(data.raw.technology["lithium-processing"].effects,
			{
				recipe = "electrolyser",
				type = "unlock-recipe"
			}
		)
		remove_tech_recipe_unlock("electrolysis-1", "electrolyser")
	end
end

--science tweaks does all its stuff in final fixes.. FUNNNNNNNNNNNN

local function sp_order(sp, order)
	if data.raw.tool[sp] then
		data.raw.tool[sp].order = order
	end
end

local function sp_subgroup(sp, subgroup)
	if data.raw.tool[sp] then
		data.raw.tool[sp].subgroup = subgroup
	end
end

--fix research order (why *does* the mod change the order AND THE SUBGROUP??????????)

sp_order("science-pack-1", "a[science-pack-1]")
sp_order("science-pack-2", "b[science-pack-2]")
sp_order("science-pack-3", "c[science-pack-3]")
sp_order("military-science-pack", "d[military-science-pack]")
sp_order("production-science-pack", "e-c-a")
sp_order("high-tech-science-pack", "f-b")

sp_subgroup("science-pack-1", "science-pack")
sp_subgroup("science-pack-2", "science-pack")
sp_subgroup("science-pack-3", "science-pack")
sp_subgroup("military-science-pack", "science-pack")
sp_subgroup("production-science-pack", "science-pack")
sp_subgroup("high-tech-science-pack", "science-pack")

--fix bobtech ones
sp_order("logistic-science-pack", "e-c-b")
sp_order("science-pack-gold", "e-b-a")

if data.raw["tool"]["alien-science-pack-blue"] then --fix bobtech alien ones if they exist
	sp_order("alien-science-pack", "e-b-b")
	sp_order("alien-science-pack-blue", "e-b-c")
	sp_order("alien-science-pack-orange", "e-b-d")
	sp_order("alien-science-pack-purple", "e-b-e")
	sp_order("alien-science-pack-yellow", "e-b-f")
	sp_order("alien-science-pack-green", "e-b-g")
	sp_order("alien-science-pack-red", "e-b-h")
end

--for some reason the mod doesn't change this???

if data.raw["recipe"]["high-tech-science-pack"] then
	data.raw["recipe"]["high-tech-science-pack"].order = "a[high-tech-science-pack]"
end

--fix power armor + equipment from bobs warfare by adding high-tech-science-pack to it so it shows up later (high tech is necessary for prereq anyways)
local function add_sp(tech, sp, count)
	if data.raw.technology[tech] then
		local bla = true
		for _, v in pairs(data.raw.technology[tech].unit.ingredients) do
			if v[1] == sp then
				return
			end
		end
		table.insert(data.raw.technology[tech].unit.ingredients, {sp, count})
	end
end
add_sp("bob-power-armor-3", "high-tech-science-pack", 1)
add_sp("energy-shield-equipment-4", "high-tech-science-pack", 1)
add_sp("battery-equipment-4", "high-tech-science-pack", 1)
add_sp("fusion-reactor-equipment-2", "high-tech-science-pack", 1)

add_sp("bob-power-armor-4", "high-tech-science-pack", 1)
add_sp("energy-shield-equipment-5", "high-tech-science-pack", 1)
add_sp("battery-equipment-5", "high-tech-science-pack", 1)
add_sp("fusion-reactor-equipment-3", "high-tech-science-pack", 1)

add_sp("bob-power-armor-5", "high-tech-science-pack", 1)
add_sp("energy-shield-equipment-6", "high-tech-science-pack", 1)
add_sp("battery-equipment-6", "high-tech-science-pack", 1)
add_sp("fusion-reactor-equipment-4", "high-tech-science-pack", 1)