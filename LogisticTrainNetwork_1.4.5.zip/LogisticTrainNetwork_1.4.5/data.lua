require ("config")
require ("lib")

require ("prototypes.technology")
require ("prototypes.recipes")
require ("prototypes.items")
require ("prototypes.entities")
require ("prototypes.signals")
