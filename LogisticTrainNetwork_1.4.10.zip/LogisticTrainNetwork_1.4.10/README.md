# Factorio - Logistic Train Network
Factorio mod  adding "logistic-train-stops" acting as anchor points for building a train powered logistic network.<br/>
It can handle multiple train configurations and will pick the best available train for a delivery.<br/>
With Choumiko's RailTanker it will also deliver liquids.<br/>

Forum: https://forums.factorio.com/viewtopic.php?f=97&t=36976<br/>
Download: https://mods.factorio.com/mods/Optera/LogisticTrainNetwork<br/>
