require "setup"

for k,v in pairs(seablockconfig.data) do
  settings.startup[k] = {}
  settings.startup[k].value = v[2]
end
