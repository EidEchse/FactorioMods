seablockconfig:extend({
  {'sct-recipes', 'string-setting', 'bobsmods'},
})
