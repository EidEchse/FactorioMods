seablockconfig:extend({
  {'bobmods-enemies-enableartifacts', 'bool-setting', true},
  {'bobmods-enemies-enablesmallartifacts', 'bool-setting', true},
  {'bobmods-enemies-enablenewartifacts', 'bool-setting', true},
  {'bobmods-enemies-aliensdropartifacts', 'bool-setting', false}
})
