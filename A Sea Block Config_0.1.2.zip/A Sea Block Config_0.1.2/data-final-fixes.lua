-- Undo boblogistic changes to underground belt lengths, and reduce length of purple and green belts
data.raw['underground-belt']['fast-underground-belt'].max_distance = 7
data.raw['underground-belt']['express-underground-belt'].max_distance = 9
if data.raw['underground-belt']['green-underground-belt'] then
  data.raw['underground-belt']['green-underground-belt'].max_distance = 11
end
if data.raw['underground-belt']['purple-underground-belt'] then
  data.raw['underground-belt']['purple-underground-belt'].max_distance = 13
end

-- Increase energy consumption of bob's extra beacons
-- Also reduce module slots and effectivity
if data.raw.beacon['beacon-2'] then
  data.raw.beacon['beacon-2'].energy_usage = "960kW"
  data.raw.beacon['beacon-2'].module_specification.module_slots = 3
  data.raw.beacon['beacon-2'].distribution_effectivity = 0.5
end
if data.raw.beacon['beacon-3'] then
  data.raw.beacon['beacon-3'].energy_usage = "1920kW"
  data.raw.beacon['beacon-3'].module_specification.module_slots = 4
  data.raw.beacon['beacon-3'].distribution_effectivity = 0.5
end

